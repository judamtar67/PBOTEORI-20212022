package excercise2;
public class TelevisiJadul extends Elektronik{
    private String modelInput;

    public TelevisiJadul() {
        this.modelInput="DVI";
    }

    public String getModelInput() {
        return modelInput;
    }
}
