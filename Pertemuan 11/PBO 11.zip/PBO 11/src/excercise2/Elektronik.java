package excercise2;
public class Elektronik {
    protected int voltase;

    public Elektronik() {
        this.voltase=220;
    }

    public int getVoltase() {
        return voltase;
    }
    
}
